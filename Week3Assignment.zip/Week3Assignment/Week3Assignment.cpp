#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>

using namespace std;

class Student {
private:
    string firstname;
    string lastname;
    int grade;

public:
    void getFirstName(string);
    void getLastName(string);
    void getGrade(int);
};

void Student::getFirstName(string fn) {
}

void Student::getLastName(string ln) {
}

void Student::getGrade(int g) {
}


int main()
{
    vector <Student> studentList;
    vector <string> nameList;
    vector <int> gradeList;

    int grade;
    string firstname;
    string lastname;

    ifstream myfile("example.txt");

    string currentLine;

    if (myfile.is_open())
    {
        while (getline(myfile, currentLine, ' '))
        {
            for (int i = 0; i < 18; i++)
            {
                cout << line;
                if (i % 3 == 0)
                {
                     cout << endl;
                }
            }
        }
    }
    else
        cout << "Unable to open file. \n";

    return (0);

    

    

}


